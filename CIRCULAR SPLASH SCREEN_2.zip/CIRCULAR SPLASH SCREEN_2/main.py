import sys
from PySide6.QtCore import *
from PySide6.QtGui import *
from PySide6.QtWidgets import *

from ui_main import Ui_MainWindow # ui_main.py
from ui_splash_screen import Ui_SplashScreen # ui_splash_screen.py
from widgets import CircularProgress # circular_progress.py


# Globals
counter = 0


# Main Window
class MainWindow(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.ui = Ui_MainWindow() # Class = line 6
        self.ui.setupUi(self)


class SplashScreen(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.ui = Ui_SplashScreen() # Class = line 7
        self.ui.setupUi(self)

        # Remove Title Bar
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        # Import Circular Progress
        self.progress = CircularProgress() # Class = line 8
        self.progress.width = 270
        self.progress.height = 270
        self.progress.value = 0
        self.progress.setFixedSize(self.progress.width, self.progress.height)
        self.progress.move(15, 15)
        self.progress.font_size = 25
        self.progress.add_shadow(True)
        self.progress.progress_width = 13
        self.progress.progress_color = QColor(0xbd93f9)
        self.progress.bg_color = QColor(68, 71, 90, 140)
        self.progress.setParent(self.ui.centralwidget)
        self.progress.show()

        # Add Drop Shadow
        self.shadow = QGraphicsDropShadowEffect(self)
        self.shadow.setBlurRadius(15)
        self.shadow.setXOffset(0)
        self.shadow.setYOffset(0)
        self.shadow.setColor(QColor(0, 0, 0, 80))
        self.setGraphicsEffect(self.shadow)

        # QTimer
        self.timer = QTimer()
        self.timer.timeout.connect(self.update)
        self.timer.start(15)  # Loading Time

        self.show() # Start SplashScreen


    # Update Progress Bar Percent
    def update(self):
        global counter

        self.progress.set_value(counter) # Set Value To Progress Bar

        if counter >= 100: # Close Splash Screen And Open Main App

            self.timer.stop() # Stop Timer

            # Show Main Window
            self.main = MainWindow()
            self.main.show()

            self.close() # Close Splash Sreen

        # Increase Counter
        counter += 1





if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon("icon.ico"))
    screen = SplashScreen()
    window = MainWindow()
    sys.exit(app.exec_())